package org.example;

import org.openqa.selenium.chrome.ChromeDriver;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        ChromeDriver driver = new ChromeDriver();

            driver.get("https://www.google.com/");

            String actualUrl = "https://www.google.com/";
            String actualtitle = "Google";
            String expectedUrl = driver.getCurrentUrl();
            String expectedtitle = driver.getTitle();

            if (actualUrl.equals(expectedUrl) & actualtitle.equals(expectedtitle) ) {
                System.out.println("Test Passed");
            }
            else {
                System.out.println("Test Failed");
            }
            driver.quit();

        }
    }
