package com.vta.ui.models.tv;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TVModule {

	@FindBy(xpath="//a[@role='button'][normalize-space()='TV']")
	public WebElement Tv_tab;
	
	@FindBy(xpath="//ul[@class='cmp-navigation__group show-menu']//a[@title='Spectrum Cable TV'][normalize-space()='Spectrum Cable TV']")
	public WebElement click_spectrum_Cable_TV;
	
	@FindBy(xpath="//div[@id='localization-e15523b5bddesktop']//span[@class='sp-find'][normalize-space()='Find Best Offers']")
	static
	public WebElement Spectrum_TV_offers;
	
	@FindBy(xpath="//input[@id='address1-desktop']")
	public WebElement Spectrum_TV_stAddress;
	
	@FindBy(xpath="//input[@id='apt-desktop']")
	public WebElement Spectrum_TV_aptUnit;
	
	@FindBy(xpath="//input[@id='zip-desktop']")
	public WebElement Spectrum_TV_zipCode;
	
	@FindBy(xpath="//div[@id='localization-e15523b5bddesktop']//button[@aria-label='ENTER YOUR ADDRESS FOR BEST OFFERS'][normalize-space()='Go']")
	public WebElement Click_Go_Button;

	@FindBy(xpath="//a[@role='button' and @data-linkname='Internet']")
	WebElement Internet_tab;
	
	
	@FindBy(xpath="(//a[contains(text(),'Spectrum Internet')])[1]")
	WebElement click_spectrum_Internet;
	
	@FindBy(xpath="//div[@class='spectrum-logo-container false']")
	static
	WebElement Spectrum_mobile_logo;
	
	@FindBy(xpath="//a[@id='collapsible-nav-dropdown-1']")
	WebElement Hover_over_product;
	
	@FindBy(xpath="//a[@class='dropdown-item' and @data-linkname='Phones']")
	WebElement Select_phones;
	
	@FindBy(xpath="//h1[contains(text(),'Shop the Newest Smartphones')]")
	WebElement shop_newest_phones;
	
	@FindBy(xpath="//a[@id='button-3c1e52eb88']")
	WebElement shop_now;
	
	@FindBy(xpath="//li[@id='APL']")
	WebElement iphone_tab;
	
	@FindBy(xpath="//h1[contains(text(),'Shop New Apple iPhones')]")
	WebElement iphone_apple_des;
	
	@FindBy(xpath="//img[@alt='Apple iPhone 14 Pro Max Deep Purple']")
	WebElement iphone_14_promax;
	
	@FindBy(xpath="//button[@aria-label='Gold' and @title='Gold']")
	WebElement select_iphone_colcor;
	
	@FindBy(xpath="//span[contains(text(),'256 GB')]")
	WebElement select_storage;
	
	@FindBy(xpath="//li[@aria-label='slide item 2']")
	WebElement choose_second_picture;
	
	@FindBy(xpath="//span[contains(text(),'when it ships')]")
	WebElement when_ship;
	
	@FindBy(xpath="//span[contains(text(),'$15/mo plus tax, if applicable')]")
	WebElement protection_plan;
	
	@FindBy(xpath="//button[contains(text(),'Add Trade-In')]")
	WebElement Add_TradeIn;
	
	@FindBy(xpath="//div[contains(text(),'Trade-In')]")
	WebElement TradeIn_logo;
	
	@FindBy(xpath="//img[@alt='ATT']")
	WebElement select_ATT;
	
	@FindBy(xpath="//img[@alt='Apple']")
	WebElement select_apple;
	
	@FindBy(xpath="//input[@id='modelAutoComplete']")
	WebElement inputfield;
	
	@FindBy(xpath="//li[contains(text(),'IPAD 10 10.9')]")
	WebElement select_fromdropdown;
	
	@FindBy(xpath="//button[contains(text(),'256GB')]")
	WebElement storage;
	
	@FindBy(xpath="//button[contains(text(),'CONTINUE')]")
	WebElement click_continue;
	
	@FindBy(xpath="//input[@name='imeiNumber']")
	WebElement imei_Number;
	
	@FindBy(xpath="//input[@name='DAM_FREE_CTI' and @value='DAMF_YES']")
	WebElement click_yes;
	
	@FindBy(xpath="//input[@name='LCD_GOOD_CTI' and @value='LCDG_YES']")
	WebElement second_yes;
	
	@FindBy(xpath="//input[@name='NO_LIQUID_CTI' and @value='NOLIQ_NO']")
	WebElement first_No;
	
	@FindBy(xpath="//input[@name='POWER_ON_CTI' and @value='POWER_NO']")
	WebElement second_no;
	
	@FindBy(xpath="//div[contains(text(),'This device is not eligible for Trade-In.')]")
	WebElement message;
	
	@FindBy(xpath="//button[contains(text(),'Cancel')]")
	WebElement cancel;
	
	@FindBy(xpath="//button[text()='NO, SHOP INTERNET']")
	WebElement shop_internet;
	
	@FindBy(xpath="//button[@class='cmp-button' and @data-linktype='orange_button']")
	WebElement order_now1;
	
	
	@FindBy(xpath="//button[@class='show-more']")
	WebElement show_less;
	
	@FindBy(xpath="//input[@name='line1']")
	WebElement enter_address;
	
	@FindBy(xpath="//input[@name='line2']")
	WebElement app_unit;
	
	@FindBy(xpath="//input[@name='postalCode']")
	WebElement zipcode;
	
	@FindBy(xpath="//button[@value='Find Offers']")
	WebElement find_finder;
	
	@FindBy(xpath="//div[contains(text(),'S Park Ave, Fl 26, 10016')]")
	WebElement location;
	
	@FindBy(xpath="//button[text()='YES, SIGN IN']")
	WebElement sign_in;
	
	@FindBy(xpath="//a[contains(text(),'Create a Username')]")
	WebElement create_user;
	
	@FindBy(xpath="//input[@id='contact-info-input']")
	WebElement email_address;
	
	@FindBy(xpath="//input[@id='cc-username']")
	
	WebElement login_email;
	
	@FindBy(xpath="//input[@id='cc-user-password']")
	WebElement login_password;
	
	@FindBy(xpath="//button[@size='lg']")
	WebElement click_signin;
	
	
	@FindBy(xpath="//div[@class='recaptcha-checkbox-border']")
	WebElement recaptcha;
	
	@FindBy(xpath="//button[@class='kite-btn kite-btn-primary kite-btn-lg']")
	WebElement click_next;
	
	@FindBy(xpath="//h3[@class='localization-error__error-text']")
	WebElement large_text;
	
	@FindBy(id="title-bf9fd1c3f8")
	WebElement shop_newphone;
	
	@FindBy(id="title-8679fcab7a")
	WebElement shop_newapplephone;
	
	@FindBy(xpath="//h1[contains(text(),'Are You a Spectrum Customer?')]")
	WebElement pectrumornot;
	
	@FindBy(xpath="//div[@class='ngk-alert-inline-wrapper']")
	WebElement error_message;
	
	@FindBy(xpath="//a[contains(text(),'Motorola')]")
	static
	WebElement motorola_tab;
	
	@FindBy(xpath="//a[contains(text(),'Google')]")
	WebElement Google_tab;
	
	@FindBy(xpath="//a[contains(text(),'Samsung')]")
	WebElement samsung_tab;
	
	@FindBy(xpath="//span[contains(text(),'SHOP ULTRA')]")
	WebElement shop_ultra;
	
	@FindBy(xpath="//button[@id='dropdown-basic-button-sortBy']")
	WebElement dropdown;
	
	@FindBy(xpath="//a[contains(text(),'Price Low-High')]")
	WebElement select_Fromdropdown;
	
	
	
	@FindBy(xpath="//a[@title='Packages' and @href='/packages' and @class='cmp-navigation__item-link' and @role='button']")
	WebElement p;
	
	public TVModule(WebDriver d){
		
		PageFactory.initElements(d,this);
	}
}
