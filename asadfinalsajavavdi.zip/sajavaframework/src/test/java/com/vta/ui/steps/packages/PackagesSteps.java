package com.vta.ui.steps.packages;


import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import com.vta.ui.models.packages.PackagesModule;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PackagesSteps {
	UIManager mgr = new UIManager(BrowserType.CHROME32);
	PackagesModule common_methods = new PackagesModule(mgr.driver);

	@When("enter URL in address bar {string}")
	public void enter_url_in_address_bar(String url) {
		mgr.startSession(url);
		mgr.maximizeBrowser();
	}

	@Then("verify that title page is {string}")
	public void open_website(String title) {
		String actual_title = mgr.getTitle();
		UIManager.assertEqual(actual_title, title, "verification check");
	}

	@Then("close the browser")
	public void close_the_browser() {
		mgr.endSession();
	}

	@When("hover on packages tab")
	public void hover_on_packages_tab() {
		mgr.waitUntilVisible(common_methods.packages_tab);
		mgr.hover(common_methods.packages_tab);

	}

	@And("click on packages tab")
	public void click_on_packages_tab() throws InterruptedException {
		mgr.waitUntilVisible(common_methods.packages_tab);
		mgr.click(common_methods.packages_tab);
		Thread.sleep(4000);
	}

	@Then("packages page open {string}")
	public void packages_page_open(String title) {
		String actual_title = mgr.getTitle();
		UIManager.assertEqual(actual_title,title,"verification check");

	}

	@And("dropdown tabs open")
	public void dropdown_tabs_open() {
		UIManager.assertTrue(common_methods.packages_dropdown.isDisplayed(),"verification check");
	}

	@And("click on shop packages tab")
	public void click_on_shop_packages_tab() {
		mgr.waitUntilVisible(common_methods.dropdown_shop_packages);
		mgr.click(common_methods.dropdown_shop_packages);
	}

	@Then("shop packages page open")
	public void shop_packages_page_open() {
		UIManager.assertTrue(common_methods.verify_shoppackages_page.isDisplayed(), "verification check");
	}

	@When("scroll down page")
	public void scroll_down_page() throws InterruptedException {
		Thread.sleep(4000);
		mgr.scroll(common_methods.choose_internet_speed_300Mbps, false);
	}

	@And("select 300Mbps internet speed")
	public void select_300mbps_internet_speed() {
		mgr.click(common_methods.choose_internet_speed_300Mbps);
	}

	@Then("click on Get offer")
	public void click_on_get_offer() {
		mgr.waitUntilVisible(common_methods.Getoffer_button);
		mgr.click(common_methods.Getoffer_button);
	}

	@When("enter street address in text field")
	public void enter_street_address_in_text_field()  {
		mgr.waitUntilVisible(common_methods.street_address);
		mgr.fillTextField(common_methods.street_address, "41 Brenton Rd");
	}

	@And("enter Apt number in text field")
	public void enter_Apt_number_in_text_field() {
		mgr.waitUntilVisible(common_methods.Apt_Unit);
		mgr.fillTextField(common_methods.Apt_Unit, "");
	}

	@And("enter zipcode in text field")
	public void enter_zipcode_in_text_field() {
		mgr.waitUntilVisible(common_methods.zipcode);
		mgr.fillTextField(common_methods.zipcode, "76134");
	}

	@And("click on GO")
	public void click_on_go() {
		mgr.click(common_methods.Go_button);
	}

	@Then("verify that internetSpeed page open")
	public void verify_that_internetSpeed_page_open() {
		mgr.waitUntilVisible(common_methods.internetAssistButton);
		UIManager.assertTrue(common_methods.internetAssistButton.isDisplayed(), "verification check");
	}

	@Then("click on Internet Assist Button")
	public void click_internet_assist_button() {
		mgr.waitUntilVisible(common_methods.internetAssistButton);
		mgr.click(common_methods.internetAssistButton);
	}

	@Then("verify that equipment page open")
	public void verify_that_equipment_page_open() {
		mgr.waitUntilVisible(common_methods.fiberModemCheckbox);
		UIManager.assertTrue(common_methods.fiberModemCheckbox.isDisplayed(), "verification check");
	}

	@Then("Select Free Modem Checkbox")
	public void select_Free_Modem_Checkbox() {
		mgr.waitUntilVisible(common_methods.fiberModemCheckbox);
		mgr.click(common_methods.fiberModemCheckbox);

	}

	@Then("User Click on Continue Button")
	public void user_Click_on_Continue_Button() throws InterruptedException {
		Thread.sleep(4000);
		mgr.waitUntilVisible(common_methods.continueButton);

		mgr.click(common_methods.continueButton);

	}

	@Then("Verify checkout page")
	public void Verify_checkout_page() {
		mgr.waitUntilVisible(common_methods.checkoutFname);
		UIManager.assertTrue(common_methods.checkoutFname.isDisplayed(), "verification check");

	}
	@Then("user enter first name in text field")
	public void user_enter_first_name_in_text_field()  {
		mgr.waitUntilVisible(common_methods.checkoutFname);
		mgr.fillTextField(common_methods.checkoutFname, "Abdul");
	}
	@Then("user enter last name in text field")
	public void user_enter_last_name_in_text_field()  {
		mgr.waitUntilVisible(common_methods.lastNameField);
		mgr.fillTextField(common_methods.lastNameField, "shakoor");
	}
	@Then("user enter email address in text field")
	public void user_enter_email_address_in_text_field()  {
		mgr.waitUntilVisible(common_methods.emailField);
		mgr.fillTextField(common_methods.emailField, "shakoor@gmail.com");
	}
	@Then("user enter mobile number in text field")
	public void user_enter_mobile_number_in_text_field()  {
		mgr.waitUntilVisible(common_methods.phoneNumberField);
		mgr.fillTextField(common_methods.phoneNumberField, "(566) 554-4548");
	}
	@Then("choose mobile type")
	public void choose_mobile_type()  {
		mgr.waitUntilVisible(common_methods.phoneTypeMobile);
		mgr.click(common_methods.phoneTypeMobile);
	}
	@Then("choose monthly billing statement notification type")
	public void choose_monthly_billing_statement_notification_type()  {
		mgr.waitUntilVisible(common_methods.emailPaperless);
		mgr.click(common_methods.emailPaperless);
	}
	@Then("select check box for text message notification")
	public void select_check_box_for_text_message_notification()  {
		mgr.waitUntilVisible(common_methods.textMessageCheckbox);
		mgr.click(common_methods.textMessageCheckbox);
	}
	@Then("user enter date of birth in text field")
	public void user_enter_date_of_birth_in_text_field()  {
		mgr.scroll(common_methods.completeOrderButton);
		mgr.waitUntilVisible(common_methods.dateOfBirth);
		mgr.fillTextField(common_methods.dateOfBirth, "05/05/1992");
	}
	@Then("select free pro installation checkbox")
	public void select_free_pro_installation_checkbox() throws InterruptedException {

		Thread.sleep(4000);
		mgr.waitUntilVisible(common_methods.proInstallCheckbox);
		mgr.click(common_methods.proInstallCheckbox);
	}
	@Then("click on complete order button")
	public void click_on_complete_order_button()  {
		mgr.waitUntilVisible(common_methods.completeOrderButton);
		mgr.click(common_methods.completeOrderButton);
	}

	@Then("user navigate back to previous page")
	public void user_navigate_back_to_previous_page() throws InterruptedException {
		Thread.sleep(3000);
		mgr.navigateTo("https://www.spectrum.com/packages");
	}

	@When("select 500Mbps internet speed")
	public void select_500mbps_internet_speed() {
		mgr.click(common_methods.choose_internet_speed_500Mbps);
	}

	@When("select 1Gbps internet speed")
	public void select_1gbps_internet_speed() {
		mgr.click(common_methods.choose_internet_speed_1Gbps);
	}

	@When("scroll downs page")
	public void scroll_downs_page() throws InterruptedException {
		Thread.sleep(2000);
		mgr.scroll(common_methods.TV_monthly_charges, false);
	}

	@And("select TV service")
	public void select_TV_service() {
		mgr.click(common_methods.TV_Service);
	}

	@And("select Internet service")
	public void select_Internet_service() {
		mgr.click(common_methods.internet_Service);
	}

	@And("select Home Phone service")
	public void select_Home_Phone_service() {
		mgr.click(common_methods.home_phone_Service);
	}

	@And("enter street address2 in text field")
	public void enter_street_address2_in_text_field() {
		mgr.fillTextField(common_methods.street_address2, "71 ST. NICHOLAS DRIVE");
	}

	@And("enter Apt number2 in text field")
	public void enter_Apt_number2_in_text_field() {
		mgr.fillTextField(common_methods.Apt_Unit2, "UNIT 9");
	}

	@And("enter zipcode2 in text field")
	public void enter_zipcode2_in_text_field() {
		mgr.fillTextField(common_methods.zipcode2, "99705");
	}

	@And("click on GO2")
	public void click_on_go2() {
		mgr.click(common_methods.Go2_button);
	}

	@And("click on Spectrum One tab")
	public void click_on_Spectrum_One_tab() {
		mgr.click(common_methods.Spectrum_One);
	}

	@Then("Spectrum One page open")
	public void Spectrum_One_page_open() {
		UIManager.assertTrue(common_methods.verify_Spectrum_One_page.isDisplayed(), "verification check");
	}

	@When("scroll down page spectrum one")
	public void scroll_down_page_spectrum_one() throws InterruptedException {
		Thread.sleep(2000);
		mgr.scroll(common_methods.Get_offer2_button, false);
	}

	@When("click on Get Offer button")
	public void click_on_get_offer_button() {
		mgr.click(common_methods.Get_offer2_button);
	}

	@And("address page open")
	public void address_page_open() {
		mgr.waitUntilVisible(common_methods.verify_address_page);
		UIManager.assertTrue(common_methods.verify_address_page.isDisplayed(), "verification check");
	}

	@And("enter street address3 in text field")
	public void enter_street_address3_in_text_field() {
		mgr.waitUntilVisible(common_methods.street_address3);
		mgr.fillTextField(common_methods.street_address3, "71 ST. NICHOLAS DRIVE");
	}

	@And("enter Apt number3 in text field")
	public void enter_apt_number3_in_text_field() {
		mgr.waitUntilVisible(common_methods.Apt_Unit3);
		mgr.fillTextField(common_methods.Apt_Unit3, "UNIT 9");
	}

	@And("enter zipcode3 in text field")
	public void enter_zipcode3_in_text_field() {
		mgr.waitUntilVisible(common_methods.zipcode3);
		mgr.fillTextField(common_methods.zipcode3, "99705");
	}

	@And("scroll down address page")
	public void scroll_down_address_page() {
		mgr.scroll(common_methods.Find_Offers_button, false);
	}

	@And("click on Find Offers button")
	public void click_on_find_offers_button() {
		mgr.click(common_methods.Find_Offers_button);
	}

	@Then("verify GCI page")
	public void verify_GCI_page() throws InterruptedException {
		Thread.sleep(40000);
		mgr.waitUntilVisible(common_methods.GCI_logo);
		UIManager.assertTrue(common_methods.GCI_logo.isDisplayed(), "verification check");
	}

	@And("navigate to previous page")
	public void navigate_to_previous_page() {
		mgr.navigateTo("https://www.spectrum.com/packages/spectrum-one");
	}

}
