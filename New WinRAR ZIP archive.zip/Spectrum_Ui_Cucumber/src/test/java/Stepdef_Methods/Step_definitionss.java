package Stepdef_Methods;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Step_definitionss {
	
	static WebDriver driver=new FirefoxDriver();
	//static WebDriver driver=new ChromeDriver();
	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(100));
	AllMethods object =new AllMethods(driver);
	
	@BeforeTest
	@BeforeAll
	public static void before() {
//		 ChromeOptions chromeOptions = new ChromeOptions();
//		 chromeOptions.addArguments("--remote-allow-origins=*");
//		 ChromeDriver driver = new ChromeDriver(chromeOptions);
//		 System.setProperty("webdriver.http.factory", "jdk-http-client");
		 //System.setProperty("webdriver.chrome.driver","C:\\Users\\Hassan\\Desktop\\chromedriver_win32 (3)\\chromedriver.exe");
		 System.setProperty("webdriver.gecko.driver","C:\\Users\\Hassan\\Downloads\\geckodriver-v0.32.2-win32\\geckodriver.exe");
		 //driver.get("https://www.spectrum.com/");
		 //driver.manage().window().maximize();
	}
	
	@Test()
	@When("I navigate  {string}")
	public void Navigate_To_URL(String URL) throws IOException {
		 driver.get(URL);
		
	}
	
	@Test
	@And("Maximixe the window")
	public void Hover() throws IOException {
		driver.manage().window().maximize();
		
	}
	
	@Test
	@Then("Verify that the title of page should be {string}")
	public void Verify_title(String Title){
		String actual_Title=driver.getTitle();
		assertEquals(Title,actual_Title);
		
	}
	@Test
	@Given("User is on Home page of Spectrum.com")
	public void Home_page() {
		System.out.println("spectrum");
		
	}
	
	@Test
	@When("User Hover over on Mobile Tab")
	public void User_Hover_over_on_Mobile_Tab() {
		
		object.Hover_Mobiletab();
	    
	}
	
	@Test
	@Then("Verify that User must see {string} in dropdown")
	public void Verify_Hoverover_effect_Mobile_tab(String Text) {
		String getText=AllMethods.click_spectrum_Mobile.getText();
		assertEquals(Text,getText);
		
	    
	}
	
	@Test
	@When("User click on Spectrum Mobile")
	public void User_Click_on_Mobile_Tab() {
		
		object.Click_Spectrum_Mobile();
	    
	}
	
	@Test
	@Then("Verify that the URL of the page should be {string}")
	public void Verify_URL(String URL) {
		String actual_Title=driver.getCurrentUrl();
		assertEquals(URL,actual_Title);
		
	    
	}
	
	@Test
	@When("User Hover over on Products Tab")
	public void User_Hover_over_on_Sspectrum_Mobile() {
		
		object.Hover_on_Phone();
	    
	}
	@Test
	@Then("Verify that User should see {string} in dropdown")
	public void Verify_Hoverover_effect_Spectrum_Mobile(String Text) {
		String getText=object.Select_phones.getText();
		assertEquals(Text,getText);
		
	    
	}
	
	@Test
	@When("User click on Phones")
	public void User_Click_on_Phone() {
		
		object.Click_Mobile();
	    
	}
	
	@Test
	@When("User click on Motorola Tab")
	public void User_Click_on_Motorola_Tab() throws InterruptedException {
		object.Click_Motorola();
		
	    
	}
	
	
	
	@Test
	@When("User click on Google Tab")
	public void User_Click_on_google_Tab() {
		object.Click_Googletab();
		
	    
	}
	
	@Test
	@When("User click on Samsung Tab")
	public void User_Click_on_samsung_Tab() {
		object.Click_Samsungtab();
		
	    
	}
	
	@Test
	@When("User clicks on Apple Tab")
	public void Shop_Now() throws InterruptedException {
	
		object.Select_Cellphones();
	    
	}
	
	@Test
	@And("Select Iphone 14 promax of Apple Brand")
	public void Select_Cellphone() throws InterruptedException {
		System.out.println("asad");
		
	}
	
	@Test
	@When("Click on Gold color")
	public void Click_color() throws InterruptedException {
		object.Select_specifications();
	}
	
	@And("Click on 128GB storage")
	public void Select_storage() throws InterruptedException {
		
		
	}
	
	@And("Click on single Iphone picture")
	public void Select_Iphonepicture() throws InterruptedException {
		
		
	}
	
	@And("Click on Payment option")
	public void Select_payment_option() throws InterruptedException {
		
		
	}
	
	@And("Click on Add protection plan")
	public void Select_protectionplan() throws InterruptedException {
		
		
	}
	
	@And("Clik on Trade_In")
	public void Select_Trade_In() throws InterruptedException {
		
		
	}
	
	@Test
	@When("Click on AT&T option from Carrier")
	public void Click_on_ATT() throws InterruptedException {
		object.Enter_Trade_In_Informtion();
	}
	
	@And("Click on Apple from Make")
	public void Click_on_Apple_from_Make() throws InterruptedException {
		
		
	}
	
	@And("Search for Model in Model Tab")
	public void Search_for_Model_in_Model_Tab() throws InterruptedException {
		
		
	}
	
	@And("Click on 64GB storage")
	public void Click_on_64GB_storage() throws InterruptedException {
		
		
	}
	
	@Test
	@Then("Verify that the {string} button should be enabled")
	public void Verify_Continue_Button_enability(String text) {
		assertTrue(object.click_continue.isEnabled());
	    
	}
	
	@When("User Click on Continue Button")
	public void Click_on_Continue_Button() throws InterruptedException {

		object.Enter_IMEI_Informtion();
		
		
	}
	
	@Test
	@Then("Verify that the system must demand IMEI number from user")
	public void Verify_IMEI_number() {
		assertTrue(object.imei_Number.isDisplayed());
	    
	}
	
	@Test
	@When("User put all information about physical condition of Mobile")
	public void Enter_Physical_details_Of_Mobile() throws InterruptedException {
		object.Enter_physical_condition_of_Mobile();
	}
	
	
	@Test
	@When("User put all information about physical condition of Mobile cellphone")
	public void Enter_Nok_details_Of_Mobile() throws InterruptedException {
		
	}
	
	@And("Click on Continue")
	public void Click_on_Continue() throws InterruptedException {
		object.click_continue.click();
		wait.until(ExpectedConditions.visibilityOf(object.message));
		
	}
	@Test
	@Then("Verify that this message {string} is displayed")
	public void Verify_message(String text) {
		String actualtext=object.message.getText();
		assertEquals(actualtext,text);
	    
	}
	@Test
	@When("User put all information about physical condition of Mobile phone")
	public void Enter_ok_details_Of_Mobile() throws InterruptedException {
		object.physical_condition_of_Mobile();
		
	}
	
	@And("Clicks on Continue")
	public void Clicks_on_Continue() throws InterruptedException {
		object.click_continue.click();
		
		
	}
	
	@Test
	@Then("Verify that the {string} button should be displayed")
	public void Verify_apply_Button_enability(String text) {
		wait.until(ExpectedConditions.visibilityOf(object.apply));
		String actualtext=object.apply.getText();
		assertEquals(actualtext,text);
	    
	}
	
	@Test
	@When("User click on Apply Button")
	public void Click_on_spectrum_Mobile() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOf(object.apply));
		object.apply.click();
	}
	
	@When("User click on continue Button")
	public void Clicks_on_Continuee() throws InterruptedException {
		
		object.click__continue();
		
		
	}
	
	@When("User click on No shop Internet Button")
	public void Clicks_on_Noshopinternet() throws InterruptedException {
		
		object.No_Shop_Internet();
		
		
	}
	
	@Test
	@When("^enters (.*) and (.*) and enter address details$")
	public void user_fills_form_from_given_sheetname_sheet_name_and_rownumber(String SheetName,Integer RowNumber) throws InvalidFormatException, IOException, InterruptedException {
	   ExcelReader reader=new ExcelReader();
	   List<Map<String,String>> testData=reader.getData("C:\\Users\\Hassan\\Desktop\\contactdetails.xlsx", SheetName);
	   String adres=testData.get(RowNumber).get("Adrees"); 
	   String apat =testData.get(RowNumber).get("Apprt"); 
	   String zipcde=testData.get(RowNumber).get("Zipcode"); 
	   String mes=testData.get(RowNumber).get("message"); 
	   object.Enter_address(adres, apat, zipcde, mes);
	   
	}
	@Test
	@Then("it shows successfull message {string}")
	public void it_shows_successfull_message(String string)   {
		String actualmessage=object.getext();
		assertEquals(actualmessage,string);
	    
	}
	
	
}











